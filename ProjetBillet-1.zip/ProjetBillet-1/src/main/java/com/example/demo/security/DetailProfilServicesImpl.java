package com.example.demo.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.demo.entities.Profil;
import com.example.demo.repositories.ProfilRepo;

public class DetailProfilServicesImpl implements UserDetailsService {
	
	@Autowired
	private ProfilRepo profilRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Profil profil =profilRepo.getProfilByUsername(username);
		if(profil==null) {
			throw new UsernameNotFoundException("Profil non trouvé");
		}
		return new DetailProfil(profil);
	}

}
