package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Profil;
import com.example.demo.entities.Reservation;

public interface ReservationRepo extends JpaRepository<Reservation,Long>{
	//Profil findByLogin(String login);
	

}
