package com.example.demo.metiers;

import java.util.Date;
import java.util.List;

import com.example.demo.entities.Evenement;

public interface IEvenementServices {
	public List<Evenement> listAll(String keyword);
	

}
