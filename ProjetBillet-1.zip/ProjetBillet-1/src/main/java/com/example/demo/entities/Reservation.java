package com.example.demo.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Reservation implements Serializable {

	@Id @GeneratedValue
	private Long ID_RESERVATION;
	
	@ManyToOne (cascade=CascadeType.PERSIST)
	@JoinColumn(name="ID_USER")
	private Utilisateur u;
	@ManyToOne (cascade=CascadeType.PERSIST)
	@JoinColumn(name="ID_EVENT")
	private Evenement e;
	private Date date_reservation;
	private Boolean confirm;
	
	
	public Reservation() {
		super();
	}
	public Reservation(Date date_reservation, Boolean confirm) {
		super();
		this.date_reservation = date_reservation;
		this.confirm = confirm;
	}
	public Utilisateur getU() {
		return u;
	}
	public void setU(Utilisateur u) {
		this.u = u;
	}
	public Evenement getE() {
		return e;
	}
	public void setE(Evenement e) {
		this.e = e;
	}
	public Date getDate_reservation() {
		return date_reservation;
	}
	public void setDate_reservation(Date date_reservation) {
		this.date_reservation = date_reservation;
	}
	public Boolean getConfirm() {
		return confirm;
	}
	public void setConfirm(Boolean confirm) {
		this.confirm = confirm;
	}
	
	
}
