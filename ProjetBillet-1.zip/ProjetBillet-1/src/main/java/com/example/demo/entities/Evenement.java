package com.example.demo.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.*;


@Entity
public class Evenement implements Serializable{
	
	@Id @GeneratedValue
	private Long id;
	private String type;
	private String date_evenement;
	private String localisation;
	private double prix;
	private int nb_places;
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="ID_ADMIN")
	private Admin admin;
	@OneToMany(mappedBy="e", fetch=FetchType.LAZY)
	private Collection<Reservation> reservation;

	
	
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public Evenement() {
		super();
		
	}
	public Evenement(String type, String date_evenement, String localisation, double prix, int nb_places) {
		super();
		this.type = type;
		this.date_evenement = date_evenement;
		this.localisation = localisation;
		this.prix = prix;
		this.nb_places = nb_places;
	}
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDate_evenement() {
		return date_evenement;
	}
	public void setDate_evenement(String date_evenement) {
		this.date_evenement = date_evenement;
	}
	public String getLocalisation() {
		return localisation;
	}
	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	public int getNb_places() {
		return nb_places;
	}
	public void setNb_places(int nb_places) {
		this.nb_places = nb_places;
	}
	
	
	

}
