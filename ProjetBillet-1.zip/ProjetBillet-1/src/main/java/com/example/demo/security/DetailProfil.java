package com.example.demo.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.example.demo.entities.Profil;
import com.example.demo.entities.Roles;

public class DetailProfil implements UserDetails {
	private Profil profil;
	public DetailProfil(Profil profil) {
		this.profil=profil;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Set<Roles> roles=profil.getRoles();
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		
		for(Roles role:roles) {
			authorities.add(new SimpleGrantedAuthority(role.getName()));
		}
		return authorities ;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return profil.getPassword();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return profil.getUserName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return profil.isEnabled();
	}

}
