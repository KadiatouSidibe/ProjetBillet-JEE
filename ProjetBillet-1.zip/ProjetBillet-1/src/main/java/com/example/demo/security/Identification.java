package com.example.demo.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Identification {
	public static void main(String[] args) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		
		/*
		 * System.out.println(encoder.encode("utilisateur"));
		 * System.out.println(encoder.encode("administrateur"));
		 */
		 
	}

}
