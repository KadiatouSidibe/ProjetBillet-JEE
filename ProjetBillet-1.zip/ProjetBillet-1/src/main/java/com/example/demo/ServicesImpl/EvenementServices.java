package com.example.demo.ServicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entities.Evenement;
import com.example.demo.repositories.EvenementRepo;

@Service
@Transactional
public class EvenementServices {

	@Autowired
	private EvenementRepo repo;
	
	 public List<Evenement> listAll(String cle) {
         if (cle != null) {
             return repo.search(cle);
         }
        return repo.findAll();
    }
	
	public void save(Evenement evenement) {
		repo.save(evenement);
	}
	
	public Evenement get(Long id) {
		return repo.findById(id).get();
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}

}
