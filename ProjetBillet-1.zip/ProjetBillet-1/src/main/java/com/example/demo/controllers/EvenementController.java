package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.ServicesImpl.EvenementServices;
import com.example.demo.entities.Evenement;
import com.example.demo.entities.Reservation;


@Controller
public class EvenementController {
	
	
	
	@Autowired
	EvenementServices service;
	
	
	  @RequestMapping("/") public String viewHomePage(Model model,@Param("cle") String cle) {
	  List<Evenement> listEvenement = service.listAll(cle);
	  model.addAttribute("listEvenement",listEvenement); 
	  model.addAttribute("cle", cle);
	  return "index0"; 
	  }
	 

	@RequestMapping("/new")
	public String ajouter(Model model) {
		Evenement evenement=new Evenement();
		model.addAttribute(evenement);
		return "add_event";
	}
	
	
	@RequestMapping(value = "/save", method =RequestMethod.POST)
	public String saveEvent(@ModelAttribute("evenement") Evenement evenement ) {
		service.save(evenement);
		return "redirect:/";
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView modifier(@PathVariable (name="id") Long id) {
		ModelAndView mav=new ModelAndView("edit_event");
		Evenement evenement=service.get(id);
		mav.addObject("evenement",evenement);
		return mav;
	}
	
	@RequestMapping("/delete/{id}")
	public String supprimer(@PathVariable (name="id") Long id) {
		service.delete(id);
		return "redirect:/";
	}
	
	
	
	/*
	 * @GetMapping(value = "/reservation/{id}") public String details(Model
	 * model, @ModelAttribute("reservation") Reservation r ,@PathVariable Long id) {
	 * SecurityContext securityContext = SecurityContextHolder.getContext();
	 * Authentication authentication = securityContext.getAuthentication(); String
	 * id2 = null;
	 * 
	 * if (authentication != null) if (authentication.getPrincipal() instanceof
	 * UserDetails) id2 = ((UserDetails)
	 * authentication.getPrincipal()).getUsername(); else if
	 * (authentication.getPrincipal() instanceof String) id2 = (String)
	 * authentication.getPrincipal(); System.out.print("-------"+ "id evenement"+id
	 * ); Reservation res = new Reservation();
	 * 
	 * service.save(res);
	 * 
	 * 
	 * 
	 * //String user =
	 * SecurityContextHolder.getContext().getAuthentication().getName();
	 * //Evenements evenement = EvenementsRepository.getEventByid(id);
	 * 
	 * 
	 * 
	 * return "index"; }
	 */
	
}
