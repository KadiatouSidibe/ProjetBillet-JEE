package com.example.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Billet {
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="ID_RESERVATION")
	private Reservation reservation;
	
	@Id @GeneratedValue
	private Long Id_billet;

}
