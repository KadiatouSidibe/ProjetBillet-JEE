package com.example.demo.entities;
import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "admin")
public class Admin extends Profil implements Serializable {
	@OneToMany(mappedBy="admin", fetch=FetchType.LAZY)
	private Collection<Evenement> evenements;

	public Collection<Evenement> getEvenements() {
		return evenements;
	}

	public void setEvenements(Collection<Evenement> evenements) {
		this.evenements = evenements;
	}

	public Admin() {
		super();
	}

	public Admin(String nom, String prenom, int age, String userName, String password) {
		super(nom, prenom, age, userName, password);
	}

	
	
	
	

}
