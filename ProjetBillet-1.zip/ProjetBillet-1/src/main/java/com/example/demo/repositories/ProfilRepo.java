package com.example.demo.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Profil;

public interface ProfilRepo extends CrudRepository <Profil,Long> {
	
	@Query ("SELECT p from Profil p where p.userName = :userName")
	public Profil getProfilByUsername(@Param ("userName") String userName);

}
