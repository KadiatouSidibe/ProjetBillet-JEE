package com.example.demo.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "User")
public class Utilisateur extends Profil implements Serializable {
	@OneToMany(mappedBy="u", fetch=FetchType.LAZY)
	private Collection<Reservation> reservation;

	public Utilisateur() {
		super();
	}

	public Utilisateur(String nom, String prenom, int age, String userName, String password) {
		super(nom, prenom, age, userName, password);
	}
	
	
	


}
