package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entities.Evenement;

public interface EvenementRepo extends JpaRepository<Evenement,Long>{
	
	 @Query("SELECT e FROM Evenement e WHERE CONCAT(e.localisation, ' ', e.type, ' ', e.date_evenement) LIKE %?1%")
     public List<Evenement> search(String search);
	
}
