package com.example.demo.metiers;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Evenement;
import com.example.demo.repositories.EvenementRepo;

@Service
@Transactional
public class EvenementServicesIplm implements IEvenementServices{
	@Autowired
	private EvenementRepo evenementRepo;

	@Override
	public List<Evenement> listAll(String keyword) {
		if (keyword!=null) {
		}
		return evenementRepo.findAll();
	}

	
}
