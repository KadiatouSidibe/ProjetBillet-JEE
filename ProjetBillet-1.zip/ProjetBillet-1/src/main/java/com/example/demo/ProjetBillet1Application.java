package com.example.demo;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.entities.Evenement;
import com.example.demo.entities.Profil;
//import com.example.demo.metiers.IEvenementServices;
import com.example.demo.repositories.EvenementRepo;
import com.example.demo.repositories.ProfilRepo;

@SpringBootApplication
public class ProjetBillet1Application {

	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(ProjetBillet1Application.class, args);
		EvenementRepo eve= ctx.getBean(EvenementRepo.class);
		eve.save(new Evenement("type","10/10/2020","loc",12.4,2));
		
		
		
//		IEvenementServices met=ctx.getBean(IEvenementServices.class);
//		met.rechercheParType("type");
	}

}
